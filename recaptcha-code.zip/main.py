# main.py (Google Cloud Function - Python)
import requests
import os
import json
from flask import jsonify

# The verification URL for Google reCAPTCHA
VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify'

# The function must accept the request object
def verify_recaptcha(request):
    """
    Handles the asynchronous POST request from the client and verifies the reCAPTCHA token.
    """
    
    # 1. Set CORS headers (crucial for client-side JavaScript access)
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type'
    }
    
    # Handle CORS preflight requests
    if request.method == 'OPTIONS':
        return ('', 204, headers)

    # Set response type to JSON
    headers['Content-Type'] = 'application/json'

    # 2. Get the reCAPTCHA Secret Key from environment variables
    RECAPTCHA_SECRET_KEY = os.environ.get('RECAPTCHA_SECRET_KEY')
    if not RECAPTCHA_SECRET_KEY:
        return (jsonify({'success': False, 'message': 'Server misconfigured (Secret Key missing)'}), 500, headers)

    # 3. Get the data sent from the client's fetch call
    request_json = request.get_json(silent=True)
    if not request_json:
        return (jsonify({'success': False, 'message': 'Invalid request format'}), 400, headers)
        
    userResponseToken = request_json.get('g-recaptcha-response')

    if not userResponseToken:
        return (jsonify({'success': False, 'message': 'reCAPTCHA token is missing.'}), 400, headers)

    try:
        # 4. Prepare and send the server-to-server POST request to Google
        verification_data = {
            'secret': RECAPTCHA_SECRET_KEY,
            'response': userResponseToken
        }
        
        # requests.post sends the data URL-encoded, which is what Google expects
        google_response = requests.post(VERIFY_URL, data=verification_data)
        
        # 5. Check the verification result
        verification_result = google_response.json()

        if verification_result.get('success'):
            # ✅ SUCCESS
            return (jsonify({'success': True, 'message': 'Form submitted and verified!'}), 200, headers)
        else:
            # ❌ FAILURE
            return (jsonify({
                'success': False, 
                'message': 'reCAPTCHA challenge failed. Please try again.',
                'errors': verification_result.get('error-codes')
            }), 403, headers)

    except Exception as e:
        print(f"Error during verification: {e}")
        return (jsonify({'success': False, 'message': 'Verification service error.'}), 500, headers)